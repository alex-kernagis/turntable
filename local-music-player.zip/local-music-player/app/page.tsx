import MusicPlayer from '@/components/MusicPlayer'

export default function Home() {
  return (
    <main>
      <MusicPlayer />
    </main>
  )
}

